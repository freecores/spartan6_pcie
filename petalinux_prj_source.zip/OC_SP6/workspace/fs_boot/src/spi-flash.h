/*! @file spi-flash.h
 * FILE:
 */
#ifndef SPI_FLASH_H
#define SPI_FLASH_H
int spi_flash_probe();

int spi_flash_read(unsigned long offset, unsigned char *rx, int rxlen, char startflag, char endflag);

#endif
