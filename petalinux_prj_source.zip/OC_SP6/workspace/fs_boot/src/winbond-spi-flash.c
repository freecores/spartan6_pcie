#include "fs-boot.h"
#ifdef CONFIG_PRIMARY_FLASH_SPI
#include "spi-flash.h"
#include "fs-xspi.h"

#ifndef SPI_CS
#define SPI_CS 0
#endif

#define OPCODE_FAST_READ 0x0b

int spi_flash_probe()
{
	return xspi_init(0, 0);
}


int spi_flash_read(unsigned long offset, unsigned char *rx, int rxlen, char startflag, char endflag)
{
	unsigned char cmd[5];
	
	if (rx == 0 || rxlen == 0)
		return -1;

	cmd[0] = OPCODE_FAST_READ;
	cmd[1] = (unsigned char) (offset >> 16);
	cmd[2] = (unsigned char) (offset >> 8);
	cmd[3] = (unsigned char) (offset);
	cmd[4] = 0;

	if (startflag)
		xspi_xfersetup(SPI_CS);
	
	if (xspi_xfer(cmd, 5, 0, 0) != 0)
		return -1;
	if (endflag)
		return xspi_xfer(0, rxlen, rx, 1);
	else
		return xspi_xfer(0, rxlen, rx, 0);
}
#endif
