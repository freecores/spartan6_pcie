/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#include <stdio.h>
#include "xparameters.h"
#include "xil_types.h"
#include "xstatus.h"
#include "xil_testmem.h"

#include "platform.h"


struct memory_range_s {
    char *name;
    char *ip;
    unsigned base;
    unsigned size;
};

/* generated memory ranges defined in memory_ranges_g.c */
extern struct memory_range_s memory_ranges[];
extern int n_memory_ranges;

struct memory_range_s memory_ranges[] = {
    /* microblaze_0_d_bram_ctrl memory will not be tested since application resides in the same memory */
    {
        "mcb_ddr3",
        "axi_s6_ddrx",
        /*0xc0000000*/0xA9000000,
        /*134217728*/ 0x07000000,
    },
};
int n_memory_ranges = 1;

static u32 RotateLeft(u32 Input, u8 Width);

#define MYXUT_MEMTEST_INIT_VALUE  1
#define MYXUT_ALLMEMTESTS     0
#define MYXUT_INCREMENT       1
#define MYXUT_WALKONES        2
#define MYXUT_WALKZEROS       3
#define MYXUT_INVERSEADDR     4
#define MYXUT_FIXEDPATTERN    5
#define MYXUT_MAXTEST         MYXUT_FIXEDPATTERN

#define MYXST_MEMTEST_FAILED              401L  /* memory test failed */
#define MYXST_SUCCESS                     0L





void report_fail(u32 index,u32 read_value,u32 expect_value)
{
    print("fail: index=");
    putnum(index);
    print(" read=");
    putnum(read_value);
    print(" expect=");
    putnum(expect_value);
    print("\n\r");
}
int MyXUtil_MemoryTest16(u16 *Addr, u32 Words, u16 Pattern, u8 Subtest)
{
    u32 i;
    u32 j;
    u16 Val = MYXUT_MEMTEST_INIT_VALUE;
    u16 FirstVal = MYXUT_MEMTEST_INIT_VALUE;
    u16 Word;

    XASSERT_NONVOID(Words != 0);
    XASSERT_NONVOID(Subtest <= MYXUT_MAXTEST);

    /*
     * selectthe proper Subtest(s)
     */

    switch (Subtest) {

    case MYXUT_ALLMEMTESTS:

        /* this case executes all of the Subtests */

        /* fall through case statement */

    case MYXUT_INCREMENT:
        {

            /*
             * Fill the memory with incrementing
             * values starting from 'FirstVal'
             */
            for (i = 0L; i < Words; i++) {
                /* write memory location */

                Addr[i] = Val;

                Val++;
            }

            /*
             * Restore the reference 'Val' to the
             * initial value
             */

            Val = FirstVal;

            /*
             * Check every word within the Words
             * of tested memory and compare it
             * with the incrementing reference
             * Val
             */

            for (i = 0L; i < Words; i++) {

                /* read memory location */

                Word = Addr[i];

                if (Word != Val) {
                    report_fail(i,(u32)Word,(u32)Val);
                    return XST_MEMTEST_FAILED;
                }
                Val++;
            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }

        }       /* end of case 1 */

        /* fall through case statement */

    case MYXUT_WALKONES:
        {
            /*
             * set up to cycle through all possible initial test
             * Patterns for walking ones test
             */

            for (j = 0L; j < /*16*/1; j++) {
                /*
                 * Generate an initial value for walking ones test to test for bad
                 * data bits
                 */

                Val = 1 << j;

                /*
                 * START walking ones test
                 * Write a one to each data bit indifferent locations
                 */

                for (i = 0L; i < /*16*/Words; i++) {

                    /* write memory location */

                    Addr[i] = Val;

                    Val = (u16) RotateLeft(Val, 16);

                }

                /*
                 * Restore the reference 'Val' to the
                 * initial value
                 */

                Val = 1 << j;

                /* Read the values from each location that was written */

                for (i = 0L; i < /*16*/Words; i++) {

                    /* read memory location */

                    Word = Addr[i];

                    if (Word != Val) {
                        return MYXST_MEMTEST_FAILED;
                    }

                    Val = (u16) RotateLeft(Val, 16);

                }

            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }


        }       /* end of case 2 */

        /* fall through case statement */

    case MYXUT_WALKZEROS:
        {
            /*
             * set up to cycle through all possible initial
             * test Patterns for walking zeros test
             */

            for (j = 0L; j < /*16*/1; j++) {

                /*
                 * Generate an initial value for walking ones
                 * test to test for bad
                 * data bits
                 */

                Val = ~(1 << j);

                /*
                 * START walking zeros test
                 * Write a one to each data bit indifferent locations
                 */

                for (i = 0L; i < /*16*/Words; i++) {


                    /* write memory location */

                    Addr[i] = Val;
                    Val = ~((u16) RotateLeft(~Val, 16));

                }

                /*
                 * Restore the reference 'Val' to the
                 * initial value
                 */

                Val = ~(1 << j);

                /* Read the values from each location that was written */

                for (i = 0L; i < /*16*/Words; i++) {

                    /* read memory location */

                    Word = Addr[i];

                    if (Word != Val) {
                        report_fail(i,(u32)Word,(u32)Val);
                        return MYXST_MEMTEST_FAILED;
                    }

                    Val = ~((u16) RotateLeft(~Val, 16));

                }

            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }

        }       /* end of case 3 */

        /* fall through case statement */

    case MYXUT_INVERSEADDR:
        {

            /* Fill the memory with inverse of address */

            for (i = 0L; i < Words; i++) {
                /* write memory location */

                Val = (u16) (~((u32) (&Addr[i])));
                Addr[i] = Val;

            }

            /*
             * Check every word within the Words
             * of tested memory
             */

            for (i = 0L; i < Words; i++) {

                /* read memory location */

                Word = Addr[i];

                Val = (u16) (~((u32) (&Addr[i])));

                if ((Word ^ Val) != 0x0000) {
                    report_fail(i,(u32)Word,(u32)Val);
                    return MYXST_MEMTEST_FAILED;
                }
            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }


        }       /* end of case 4 */


        /* fall through case statement */

    case MYXUT_FIXEDPATTERN:
        {

            /*
             * Generate an initial value for
             * memory testing
             */

            //if (Pattern == 0) {
            //  Val = 0xDEAD;
            //}
            //else {
                Val = Pattern;

            //}

            /*
             * Fill the memory with fixed pattern
             */

            for (i = 0L; i < Words; i++) {

                /* write memory location */

                Addr[i] = Val;

            }

            /*
             * Check every word within the Words
             * of tested memory and compare it
             * with the fixed pattern
             */

            for (i = 0L; i < Words; i++) {

                /* read memory location */

                Word = Addr[i];

                if (Word != Val) {
                    report_fail(i,(u32)Word,(u32)Val);
                    return XST_MEMTEST_FAILED;
                }
            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }

        }       /* end of case 5 */

        /* this break is for the prior fall through case statements */

        break;

    default:
        {
            return MYXST_MEMTEST_FAILED;
        }

    }           /* end of switch */

    /* Successfully passed memory test ! */

    return MYXST_SUCCESS;
}
int MyXUtil_MemoryTest32(u32 *Addr, u32 Words, u32 Pattern, u8 Subtest)
{
    u32 i;
    u32 j;
    u32 Val = MYXUT_MEMTEST_INIT_VALUE;
    u32 FirstVal = MYXUT_MEMTEST_INIT_VALUE;
    u32 Word;
    //u32 and_mask=0xefffefff;
      u32 and_mask=0xffffffff;


    XASSERT_NONVOID(Words != 0);
    XASSERT_NONVOID(Subtest <= MYXUT_MAXTEST);

    /*
     * Select the proper Subtest
     */


    switch (Subtest) {

    case MYXUT_ALLMEMTESTS:

        /* this case executes all of the Subtests */

        /* fall through case statement */

    case MYXUT_INCREMENT:
        {

            /*
             * Fill the memory with incrementing
             * values starting from 'FirstVal'
             */
            for (i = 0L; i < Words; i++) {
                Addr[i] = Val;

                /* write memory location */

                Val++;
            }

            /*
             * Restore the reference 'Val' to the
             * initial value
             */

            Val = FirstVal;

            /*
             * Check every word within the Words
             * of tested memory and compare it
             * with the incrementing reference
             * Val
             */

            for (i = 0L; i < Words; i++) {
                Word = Addr[i];

                if ((Word&and_mask) != (Val&and_mask)) {
                    report_fail(i,Word,Val);
                    return MYXST_MEMTEST_FAILED;
                }

                Val++;
            }


            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }


        }       /* end of case 1 */

        /* fall through case statement */

    case MYXUT_WALKONES:
        {
            /*
             * set up to cycle through all possible initial
             * test Patterns for walking ones test
             */

            for (j = 0L; j < 1; j++) {
                /*
                 * Generate an initial value for walking ones test to test for bad
                 * data bits
                 */

                Val = 1 << j;

                /*
                 * START walking ones test
                 * Write a one to each data bit indifferent locations
                 */

                for (i = 0L; i < Words; i++) {

                    /* write memory location */

                    Addr[i] = Val;
                    Val = (u32) RotateLeft(Val, 32);

                }

                /*
                 * Restore the reference 'Val' to the
                 * initial value
                 */
                Val = 1 << j;

                /* Read the values from each location that was written */

                for (i = 0L; i < Words; i++) {
                    /* read memory location */

                    Word = Addr[i];

                    if ((Word&and_mask) != (Val&and_mask)) {
                        report_fail(i,Word,Val);
                        return MYXST_MEMTEST_FAILED;
                    }

                    Val = (u32) RotateLeft(Val, 32);

                }

            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }


        }       /* end of case 2 */

        /* fall through case statement */

    case MYXUT_WALKZEROS:
        {
            /*
             * set up to cycle through all possible
             * initial test Patterns for walking zeros test
             */

            for (j = 0L; j < 1; j++) {

                /*
                 * Generate an initial value for walking ones test to test for
                 * bad data bits
                 */

                Val = ~(1 << j);

                /*
                 * START walking zeros test
                 * Write a one to each data bit indifferent locations
                 */

                for (i = 0L; i < /*32*/Words; i++) {

                    /* write memory location */

                    Addr[i] = Val;
                    Val = ~((u32) RotateLeft(~Val, 32));

                }

                /*
                 * Restore the reference 'Val' to the
                 * initial value
                 */

                Val = ~(1 << j);

                /* Read the values from each location that was written */

                for (i = 0L; i < Words; i++) {

                    /* read memory location */

                    Word = Addr[i];

                    if ((Word&and_mask) != (Val&and_mask)) {
                        report_fail(i,Word,Val);
                        return XST_MEMTEST_FAILED;
                    }

                    Val = ~((u32) RotateLeft(~Val, 32));

                }

            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }

        }       /* end of case 3 */

        /* fall through case statement */

    case MYXUT_INVERSEADDR:
        {

            /* Fill the memory with inverse of address */

            for (i = 0L; i < Words; i++) {

                /* write memory location */

                Val = (u32) (~((u32) (&Addr[i])));

                Addr[i] = Val;

            }

            /*
             * Check every word within the Words
             * of tested memory
             */

            for (i = 0L; i < Words; i++) {

                /* Read the location */

                Word = Addr[i];

                Val = (u32) (~((u32) (&Addr[i])));

                if (((Word&and_mask) ^ (Val&and_mask)) != 0x00000000) {
                    report_fail(i,Word,Val);
                    return XST_MEMTEST_FAILED;
                }
            }

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }


        }       /* end of case 4 */


        /* fall through case statement */

    case MYXUT_FIXEDPATTERN:
        {

            /*
             * Generate an initial value for
             * memory testing
             */

            //if (Pattern == 0) {
            //  Val = 0xDEADBEEF;
            //
            //}
            //else {
                Val = Pattern;

            //}

            /*
             * Fill the memory with fixed pattern
             */

            for (i = 0L; i < Words; i++) {
                /* write memory location */

                Addr[i] = Val;

            }

            /*
             * Check every word within the Words
             * of tested memory and compare it
             * with the fixed pattern
             */

            for (i = 0L; i < Words; i++) {

                /* read memory location */

                Word = Addr[i];



                if ((Word&and_mask) != (Val&and_mask)) {
                    report_fail(i,Word,Val);
                    return MYXST_MEMTEST_FAILED;
                }
            }
            //print("fixed patten end at :");putnum(i);print(" \r\n");

            if (Subtest != MYXUT_ALLMEMTESTS) {
                return MYXST_SUCCESS;
            }

        }       /* end of case 5 */

        /* this break is for the prior fall through case statements */

        break;

    default:
        {
            return MYXST_MEMTEST_FAILED;
        }

    }           /* end of switch */

    /* Successfully passed memory test ! */

    return MYXST_SUCCESS;
}



void putnum(unsigned int num);
void print(char *ptr);

void test_memory_range(struct memory_range_s *range) {
    XStatus status;
    //u32 len=2048; OK
    //u32 len=32768; OK
#if 1
    #define MyXUtil_MemoryTest MyXUtil_MemoryTest32
    u32 len=(range->size>>2);
    #define MEMTEST_TYPE u32
#else
    #define MyXUtil_MemoryTest MyXUtil_MemoryTest16
    u32 len=(range->size>>1);
    #define MEMTEST_TYPE u16
#endif

    /* This application uses print statements instead of xil_printf/printf
     * to reduce the text size.
     *
     * The default linker script generated for this application does not have
     * heap memory allocated. This implies that this program cannot use any
     * routines that allocate memory on heap (printf is one such function).
     * If you'd like to add such functions, then please generate a linker script
     * that does allocate sufficient heap memory.
     */

    print("Testing memory region: "); print(range->name);  print("\n\r");
    print("    Memory Controller: "); print(range->ip);  print("\n\r");
    print("         Base Address: 0x"); putnum(range->base); print("\n\r");
    print("                 Size: 0x"); putnum(range->size); print (" bytes \n\r");
    print("        memtest words: 0x"); putnum(len); print (" words \n\r");

    //status = MyXil_TestMem32((u32*)range->base, 1024, 0xAAAA5555, XIL_TESTMEM_ALLMEMTESTS);
    //status = MyXUtil_MemoryTest32((u32*)range->base, 1024, 0xAAAA5555,MYXUT_ALLMEMTESTS);
    //status = MyXUtil_MemoryTest32((u32*)range->base, size32, 0xAAAA5555,MYXUT_INCREMENT);


    //basic tests
    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0xFFFFFFFF,MYXUT_FIXEDPATTERN);
    print("   0xFFFFFFFF test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0x00000000,MYXUT_FIXEDPATTERN);
    print("   0x00000000 test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0xAAAA5555,MYXUT_INCREMENT);
    print("         incr test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0xAAAA5555,MYXUT_INVERSEADDR);
    print(" inverse addr test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    //complementaty tests
    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0xAAAA5555,MYXUT_FIXEDPATTERN);
    print("   0xAAAA5555 test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0xAAAA5555,MYXUT_WALKONES);
    print("         walk ones: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    status = MyXUtil_MemoryTest((MEMTEST_TYPE*)range->base, len, (MEMTEST_TYPE)0xAAAA5555,MYXUT_WALKZEROS);
    print("        walk zeros: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");


    //status = Xil_TestMem16((u16*)range->base, 2048, 0xAA55, XIL_TESTMEM_ALLMEMTESTS);
    //status=XST_SUCCESS;
    //print("          16-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");

    //status = Xil_TestMem8((u8*)range->base, 4096, 0xA5, XIL_TESTMEM_ALLMEMTESTS);
    //status=XST_SUCCESS;
    //print("           8-bit test: "); print(status == XST_SUCCESS? "PASSED!":"FAILED!"); print("\n\r");



}

int main()
{
    int i;

    init_platform();

    print("--Starting Memory Test Application--\n\r");
    print("NOTE: This application runs with D-Cache disabled.");
    print("As a result, cacheline requests will not be generated\n\r");

    for (i = 0; i < n_memory_ranges; i++) {
        test_memory_range(&memory_ranges[i]);
    }

    print("--Memory Test Application Complete--\n\r");

    cleanup_platform();

    return 2;
}



static u32 RotateLeft(u32 Input, u8 Width)
{
    u32 Msb;
    u32 ReturnVal;
    u32 WidthMask;
    u32 MsbMask;

    /*
     * set up the WidthMask and the MsbMask
     */

    MsbMask = 1 << (Width - 1);

    WidthMask = (MsbMask << 1) - 1;

    /*
     * set the width of the Input to the correct width
     */

    Input = Input & WidthMask;

    Msb = Input & MsbMask;

    ReturnVal = Input << 1;

    if (Msb != 0x00000000) {
        ReturnVal = ReturnVal | 0x00000001;
    }

    ReturnVal = ReturnVal & WidthMask;

    return (ReturnVal);

}

