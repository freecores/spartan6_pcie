/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */

#include <stdio.h>
#include "platform.h"

void print(char *str);

#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xparameters.h"
#include "xgpio.h"
#include "stdio.h"

XGpio GpioOutput;
#define LED_DELAY     1000000
#define LED_CHANNEL 1
#define LED_MAX_BLINK   0x1

int GpioOutputExample(u16 DeviceId, u32 GpioWidth)
{
    u32 Data;
    volatile int Delay;
    u32 LedBit;
    u32 LedLoop;
    int Status;

    /*
     * Initialize the GPIO driver so that it's ready to use,
     * specify the device ID that is generated in xparameters.h
     */
     Status = XGpio_Initialize(&GpioOutput, DeviceId);
     if (Status != XST_SUCCESS)  {
          return XST_FAILURE;
     }


     /*
      * Set the direction for all signals to be outputs
      */
     XGpio_SetDataDirection(&GpioOutput, LED_CHANNEL, 0x0);

     /*
      * Set the GPIO outputs to low
      */
     XGpio_DiscreteWrite(&GpioOutput, LED_CHANNEL, 0x0);

     for (LedBit = 0x0; LedBit < GpioWidth; LedBit++)  {

        for (LedLoop = 0; LedLoop < LED_MAX_BLINK; LedLoop++) {

            /*
             * Set the GPIO Output to High
             */
            XGpio_DiscreteWrite(&GpioOutput, LED_CHANNEL,
                        1 << LedBit);

#ifndef __SIM__
            /*
             * Wait a small amount of time so the LED is visible
             */
            for (Delay = 0; Delay < LED_DELAY; Delay++);

#endif
            /*
             * Clear the GPIO Output
             */
            XGpio_DiscreteClear(&GpioOutput, LED_CHANNEL,
                        1 << LedBit);


#ifndef __SIM__
            /*
             * Wait a small amount of time so the LED is visible
             */
            for (Delay = 0; Delay < LED_DELAY; Delay++);
#endif

          }

     }

     return XST_SUCCESS;

}

int main()
{
    init_platform();

    print("Hello World\n\r");

    while(1)
     {
        u32 status;

        status = GpioOutputExample(XPAR_LEDS_DEVICE_ID,3);


     }

    cleanup_platform();

    return 0;
}

