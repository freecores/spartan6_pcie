/////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2004 Xilinx, Inc. All Rights Reserved.
//
// You may copy and modify these files for your own internal use solely with
// Xilinx programmable logic devices and  Xilinx EDK system or create IP
// modules solely for Xilinx programmable logic devices and Xilinx EDK system.
// No rights are granted to distribute any files unless they are distributed in
// Xilinx programmable logic devices.
//
/////////////////////////////////////////////////////////////////////////////////
//#warning "Please provide the correct address value for the definition FLASH_IMAGE_BASEADDR."
//#define FLASH_IMAGE_BASEADDR  0xF8000000
#define FLASH_IMAGE_BASEADDR  0x800000

